/* ==========================================================================
   main.js — sections 6–13
   Requires (loaded in index.html): GSAP 3.12, ScrollTrigger, Lenis
   ========================================================================== */
(() => {
  'use strict';

  gsap.registerPlugin(ScrollTrigger);

  /* ------------------------------------------------------------------------
     Helpers + environment
     ------------------------------------------------------------------------ */
  const $  = (sel, ctx = document) => ctx.querySelector(sel);
  const $$ = (sel, ctx = document) => Array.from(ctx.querySelectorAll(sel));

  const mqMobile = window.matchMedia('(max-width: 768px)');
  const mqTouch  = window.matchMedia('(hover: none), (pointer: coarse)');
  const reduce   = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  const isMobile  = mqMobile.matches;
  const useCursor = !mqTouch.matches && !mqMobile.matches;

  if (reduce) document.documentElement.classList.add('reduce');

  // WebGL pixel ratio (use this in your Three.js renderer for sections 1–5):
  //   renderer.setPixelRatio(window.WEBGL_PIXEL_RATIO)
  window.WEBGL_PIXEL_RATIO = Math.min(window.devicePixelRatio || 1, isMobile ? 1.5 : 2);

  // Shared pointer position (used by cursor, service preview, magnetic button)
  const pointer = { x: window.innerWidth / 2, y: window.innerHeight / 2 };
  window.addEventListener('pointermove', (e) => { pointer.x = e.clientX; pointer.y = e.clientY; }, { passive: true });

  /* ------------------------------------------------------------------------
     Lenis smooth scroll (kept on for mobile too), synced with ScrollTrigger
     ------------------------------------------------------------------------ */
  let lenis = null;
  if (!reduce && window.Lenis) {
    lenis = new Lenis({ duration: 1.2, smoothWheel: true });
    lenis.on('scroll', ScrollTrigger.update);
    gsap.ticker.add((time) => lenis.raf(time * 1000));
    gsap.ticker.lagSmoothing(0);
  }

  /* ------------------------------------------------------------------------
     Custom cursor + contextual label (data-cursor="VIEW")
     Disabled on touch / mobile.
     ------------------------------------------------------------------------ */
  function initCursor() {
    if (!useCursor) return;
    const el    = $('.cursor');
    const label = $('.cursor__label');
    if (!el) return;

    document.documentElement.classList.add('has-cursor');

    const xTo = gsap.quickTo(el, 'x', { duration: 0.35, ease: 'power3' });
    const yTo = gsap.quickTo(el, 'y', { duration: 0.35, ease: 'power3' });
    window.addEventListener('pointermove', (e) => { xTo(e.clientX); yTo(e.clientY); }, { passive: true });

    document.addEventListener('pointerover', (e) => {
      const t = e.target.closest('[data-cursor]');
      if (!t) return;
      label.textContent = t.dataset.cursor;
      el.classList.add('is-active');
    });
    document.addEventListener('pointerout', (e) => {
      const t = e.target.closest('[data-cursor]');
      if (t && !t.contains(e.relatedTarget)) el.classList.remove('is-active');
    });
  }

  /* ------------------------------------------------------------------------
     Text helpers
     ------------------------------------------------------------------------ */
  // Split an element's text into words → chars (masked, for the hero name)
  function splitChars(el) {
    const text = el.textContent.trim();
    el.textContent = '';
    const chars = [];
    text.split(' ').forEach((w) => {
      const word = document.createElement('span');
      word.className = 'word';
      word.setAttribute('aria-hidden', 'true');
      [...w].forEach((c) => {
        const mask = document.createElement('span'); mask.className = 'char';
        const inner = document.createElement('span'); inner.className = 'char__in'; inner.textContent = c;
        mask.appendChild(inner); word.appendChild(mask); chars.push(inner);
      });
      el.appendChild(word);
    });
    return chars;
  }

  // Wrap each rendered line of a paragraph in .line (measured by word offsetTop)
  function splitLines(el) {
    if (!el.dataset.text) el.dataset.text = el.textContent.trim();
    el.textContent = '';
    const words = el.dataset.text.split(/\s+/).map((w) => {
      const s = document.createElement('span'); s.textContent = w + ' '; s.style.display = 'inline-block';
      el.appendChild(s); return s;
    });
    const groups = []; let top = null;
    words.forEach((w) => {
      if (top === null || Math.abs(w.offsetTop - top) > 4) { groups.push([]); top = w.offsetTop; }
      groups[groups.length - 1].push(w.textContent);
    });
    el.textContent = '';
    return groups.map((g) => {
      const line = document.createElement('span'); line.className = 'line'; line.textContent = g.join('').trim();
      el.appendChild(line); return line;
    });
  }

  // Line-by-line fade-in on enter; re-splits on width change
  function revealLines(el) {
    if (!el || reduce) return;
    let tween, lastW = 0;
    const build = () => {
      if (tween) { tween.scrollTrigger && tween.scrollTrigger.kill(); tween.kill(); }
      const lines = splitLines(el);
      tween = gsap.fromTo(lines, { autoAlpha: 0, y: 24 }, {
        autoAlpha: 1, y: 0, duration: 0.9, ease: 'power3.out', stagger: 0.12,
        scrollTrigger: { trigger: el, start: 'top 85%' },
      });
      lastW = window.innerWidth;
    };
    build();
    let t;
    window.addEventListener('resize', () => {
      clearTimeout(t);
      t = setTimeout(() => { if (window.innerWidth !== lastW) build(); }, 250);
    });
  }

  /* ========================================================================
     HERO
     ======================================================================== */
  function initHero() {
    const hero = $('.hero');
    if (!hero) return;
    const name = $('.hero__name', hero);
    const chars = splitChars(name);
    if (reduce) return;

    // Intro: each char rises from translateY(120%) with rotateX — stagger .04s, power4.out, 1.4s
    const intro = () => gsap.fromTo(chars,
      { yPercent: 120, rotationX: -90 },
      { yPercent: 0, rotationX: 0, duration: 1.4, ease: 'power4.out', stagger: 0.04 });
    if (document.fonts && document.fonts.ready) { gsap.set(chars, { yPercent: 120 }); document.fonts.ready.then(intro); }
    else intro();

    gsap.from(['.hero__sub', '.hero__cue'], { autoAlpha: 0, y: 20, duration: 1, ease: 'power3.out', delay: 0.9, stagger: 0.15 });

    // Scroll: portrait scales 1 → 1.15 and fades; name moves up slower than scroll
    const st = { trigger: hero, start: 'top top', end: 'bottom top', scrub: true };
    gsap.to('.hero__portrait', { scale: 1.15, autoAlpha: 0, ease: 'none', scrollTrigger: st });
    gsap.to('.hero__name', { y: () => window.innerHeight * 0.35, ease: 'none', scrollTrigger: { ...st, invalidateOnRefresh: true } });
  }

  /* ========================================================================
     4. STATEMENT MARQUEE (two rows, opposite directions, scroll-velocity aware)
     ======================================================================== */
  function initStatement() {
    const rows = $$('.outline-marquee');
    if (!rows.length || reduce) return;

    const rowData = rows.map((row) => {
      const track = $('.outline-marquee__track', row);
      const first = $('span', track);
      // Fill one half so it is ≥ viewport wide, then duplicate that half → seamless -50% loop
      const need = Math.ceil(window.innerWidth / first.offsetWidth) + 1;
      for (let i = 1; i < need; i++) track.appendChild(first.cloneNode(true));
      Array.from(track.children).forEach((c) => track.appendChild(c.cloneNode(true)));
      return { track, dir: parseFloat(row.dataset.dir), x: 0 };
    });

    const BASE = 1.2;      // % of track per second at rest
    const BOOST = 0.04;    // extra speed per unit of Lenis velocity
    let boost = 0;

    gsap.ticker.add((time, deltaMs) => {
      const dt = deltaMs / 1000;
      const v = lenis ? Math.abs(lenis.velocity) : 0;
      boost += (Math.min(v * BOOST, 6) - boost) * 0.08;           // smoothed
      rowData.forEach((r) => {
        r.x += r.dir * (BASE + boost * 10) * dt;
        if (r.dir < 0 && r.x <= -50) r.x += 50;   // wrap (moving left)
        if (r.dir > 0 && r.x >= 0)   r.x -= 50;   // wrap (moving right)
        gsap.set(r.track, { xPercent: r.x });
      });
    });
    // Row moving right starts offset so it never reveals empty space
    rowData.forEach((r) => { if (r.dir > 0) r.x = -50; });
  }

  /* ========================================================================
     5. "THIS WILL FEEL DIFFERENT" (fire)
     ======================================================================== */
  function initFire() {
    const section = $('.fire');
    if (!section || reduce) return;

    // Word-by-word scrub reveal
    gsap.fromTo($$('.fw', section), { autoAlpha: 0.1, y: 40 }, {
      autoAlpha: 1, y: 0, ease: 'none', stagger: 0.25,
      scrollTrigger: { trigger: '.fire__title', start: 'top 85%', end: 'bottom 45%', scrub: true },
    });

    // Paragraph + closing line: line by line
    revealLines($('.fire__para', section));
    revealLines($('.fire__closing', section));

    // Stats: count-up on enter
    $$('.stat__val', section).forEach((el) => {
      const end = parseInt(el.dataset.count, 10);
      const obj = { v: 0 };
      el.textContent = '0';
      ScrollTrigger.create({
        trigger: el, start: 'top 90%', once: true,
        onEnter: () => gsap.to(obj, {
          v: end, duration: 2, ease: 'power2.out',
          onUpdate: () => { el.textContent = Math.round(obj.v); },
        }),
      });
    });
    gsap.from('.stat', {
      autoAlpha: 0, y: 40, duration: 0.9, stagger: 0.15, ease: 'power3.out',
      scrollTrigger: { trigger: '.stats', start: 'top 85%' },
    });
  }

  /* ========================================================================
     6. SERVICES ("LEGACY")
     ======================================================================== */
  function initServices() {
    /* --- Auto-scrolling image rail --- */
    const track = $('.rail__track');
    const rail  = $('.rail');
    if (track && rail) {
      // Duplicate items so xPercent: -50 loops seamlessly
      $$('.rail__item', track).forEach((n) => track.appendChild(n.cloneNode(true)));

      if (!reduce) {
        const loop = gsap.to(track, { xPercent: -50, ease: 'none', duration: 50, repeat: -1 });

        // Hover = pause (eased), leave = resume
        rail.addEventListener('mouseenter', () => gsap.to(loop, { timeScale: 0, duration: 0.5, ease: 'power2.out', overwrite: true }));
        rail.addEventListener('mouseleave', () => gsap.to(loop, { timeScale: 1, duration: 0.5, ease: 'power2.in',  overwrite: true }));
      }
    }

    /* --- Service names: lerped image preview follows the cursor --- */
    const preview = $('.svc-preview');
    if (!preview || !useCursor || reduce) return;

    const img = $('img', preview);
    const pos = { x: pointer.x, y: pointer.y };
    let visible = false;
    const LERP = 0.12;

    gsap.ticker.add(() => {
      if (!visible) return;
      pos.x += (pointer.x - pos.x) * LERP;
      pos.y += (pointer.y - pos.y) * LERP;
      // Tilt slightly based on horizontal velocity for a physical feel
      const tilt = gsap.utils.clamp(-8, 8, (pointer.x - pos.x) * 0.04);
      preview.style.transform = `translate3d(${pos.x}px, ${pos.y}px, 0) translate(-50%, -50%) rotate(${tilt}deg)`;
    });

    $$('.service').forEach((item) => {
      item.addEventListener('mouseenter', () => {
        img.src = item.dataset.preview;
        if (!visible) { pos.x = pointer.x; pos.y = pointer.y; }
        visible = true;
        gsap.to(preview, { autoAlpha: 1, scale: 1, duration: 0.4, ease: 'power3.out', overwrite: true });
      });
      item.addEventListener('mouseleave', () => {
        gsap.to(preview, {
          autoAlpha: 0, scale: 0.9, duration: 0.3, ease: 'power2.in', overwrite: true,
          onComplete: () => { visible = false; },
        });
      });
    });
    gsap.set(preview, { scale: 0.9 });
  }

  /* ========================================================================
     7. THE FALL (pinned transition)
     ======================================================================== */
  function initFall() {
    const section = $('.fall');
    if (!section || reduce) return;

    const stage = $('.fall__stage', section);
    const line1 = $('[data-line="1"]', section);
    const line2 = $('[data-line="2"]', section);
    const paper = $('.fall__paper', section);
    const men   = $('.fall__men', section);
    const menImg = $('img', men);

    const SCROLL_LEN = () => window.innerHeight * 3;   // pinned scroll distance
    const SPEED = 1.6;                                 // falling.gif parallax speed
    const menH  = () => men.offsetHeight || 300;

    // Initial states
    gsap.set(line2, { autoAlpha: 0 });

    const tl = gsap.timeline({
      defaults: { ease: 'none' },
      scrollTrigger: {
        trigger: section,
        start: 'top top',
        end: () => '+=' + SCROLL_LEN(),
        pin: stage,
        scrub: true,
        invalidateOnRefresh: true,
      },
    });
    // Timeline is 1 unit long ⇒ each position is a fraction of the pinned scroll.

    // Text: line 1 in → out, then line 2 in
    tl.fromTo(line1, { autoAlpha: 0, y: 40 }, { autoAlpha: 1, y: 0, duration: 0.1 }, 0)
      .to(line1, { autoAlpha: 0, y: -40, duration: 0.1 }, 0.38)
      .fromTo(line2, { autoAlpha: 0, y: 40 }, { autoAlpha: 1, y: 0, duration: 0.12 }, 0.55);

    // Background: black → deep warm dark
    tl.to(section, { backgroundColor: '#1a0e08', duration: 1 }, 0);
    tl.to(stage,   { backgroundColor: '#1a0e08', duration: 1 }, 0);

    // Falling men: travel = 1.6 × the scroll distance covered by this tween
    const FALL_START = 0.12;
    const FALL_DUR   = 0.6;
    tl.fromTo(
      men,
      { y: () => -menH() },
      { y: () => SPEED * FALL_DUR * SCROLL_LEN() - menH(), duration: FALL_DUR },
      FALL_START
    );

    // Torn paper wipes up over the section (edge first, then full cover)
    tl.fromTo(paper, { yPercent: 100 }, { yPercent: 0, duration: 0.45, ease: 'power1.in' }, 0.55);

    // Slight rotation sway on the falling men (independent loop)
    gsap.fromTo(menImg, { rotation: -6 }, {
      rotation: 6, duration: 2.2, ease: 'sine.inOut', yoyo: true, repeat: -1,
    });
  }

  /* ========================================================================
     8. GALLERY / CONTRIBUTION
     ======================================================================== */
  function initGallery() {
    const ringScroll = $('.ring__scroll');
    const ringImg    = $('.ring__img');

    if (ringImg && !reduce) {
      // Slow spin: 360deg per 30s
      gsap.to(ringImg, { rotation: 360, duration: 30, ease: 'none', repeat: -1 });

      // Scroll-linked rotation on the wrapper (stacks with the spin)
      gsap.to(ringScroll, {
        rotation: 180, ease: 'none',
        scrollTrigger: { trigger: '.gallery__head', start: 'top bottom', end: 'bottom top', scrub: true },
      });
    }

    // Clip-path inset reveal + inner image scale 1.3 → 1
    $$('.g-item').forEach((item) => {
      if (reduce) return;
      const img = $('img', item);
      const tl = gsap.timeline({
        scrollTrigger: { trigger: item, start: 'top 85%', toggleActions: 'play none none none' },
      });
      tl.fromTo(item, { clipPath: 'inset(100% 0% 0% 0%)' }, { clipPath: 'inset(0% 0% 0% 0%)', duration: 1.2, ease: 'power3.inOut' }, 0)
        .fromTo(img,  { scale: 1.3 }, { scale: 1, duration: 1.6, ease: 'power3.out' }, 0);
    });
  }

  /* ========================================================================
     9. MY WORK (pinned horizontal scroll)
     ======================================================================== */
  function initWork() {
    const pin     = $('.work__pin');
    const trackEl = $('.work__track');
    if (!pin || !trackEl || reduce) return;

    const cards   = $$('.card', trackEl);
    const counter = $('.work__counter-current');
    const total   = cards.length;
    const dist    = () => Math.max(0, trackEl.scrollWidth - window.innerWidth);

    const hTween = gsap.to(trackEl, {
      x: () => -dist(),
      ease: 'none',
      scrollTrigger: {
        trigger: pin,
        start: 'top top',
        end: () => '+=' + dist(),
        pin: true,
        scrub: 1,
        invalidateOnRefresh: true,
        onUpdate: (self) => {
          const i = Math.min(total, Math.floor(self.progress * total) + 1);
          counter.textContent = String(i).padStart(2, '0');   // counter 01–05
        },
      },
    });

    // Inner-image parallax, driven by the horizontal tween
    cards.forEach((card) => {
      const img = $('.card__media img', card);
      gsap.fromTo(img, { xPercent: -6 }, {
        xPercent: 6, ease: 'none',
        scrollTrigger: {
          trigger: card, containerAnimation: hTween,
          start: 'left right', end: 'right left', scrub: true,
        },
      });
    });
  }

  /* ========================================================================
     10. PROCESS (4 pinned steps, crossfade + vertical progress)
     ======================================================================== */
  function initProcess() {
    const section = $('.process');
    if (!section || reduce) return;

    const steps = $$('.step', section);
    const bgs   = $$('.process__bg', section);
    const bar   = $('.process__bar', section);
    const N     = steps.length;

    gsap.set(steps.slice(1), { autoAlpha: 0, y: 30 });
    gsap.set(steps[0], { autoAlpha: 1, y: 0 });

    const tl = gsap.timeline({
      defaults: { ease: 'none' },
      scrollTrigger: {
        trigger: section, start: 'top top',
        end: () => '+=' + window.innerHeight * N,
        pin: true, scrub: true, invalidateOnRefresh: true,
      },
    });

    // Progress bar runs the full length (timeline length = N units)
    tl.to(bar, { scaleY: 1, duration: N }, 0);

    // Crossfade step i-1 → i at t = i, with matching background swap
    for (let i = 1; i < N; i++) {
      const t = i - 0.2;
      tl.to(steps[i - 1], { autoAlpha: 0, y: -30, duration: 0.35, ease: 'power1.inOut' }, t)
        .fromTo(steps[i],  { autoAlpha: 0, y: 30 }, { autoAlpha: 1, y: 0, duration: 0.35, ease: 'power1.inOut' }, t + 0.1)
        .to(bgs[i - 1], { opacity: 0, duration: 0.5, ease: 'power1.inOut' }, t)
        .to(bgs[i],     { opacity: 1, duration: 0.5, ease: 'power1.inOut' }, t);
    }
  }

  /* ========================================================================
     11. VISUAL JOURNAL
     ======================================================================== */
  function initJournal() {
    if (reduce) return;

    $$('.post').forEach((post, i) => {
      const media = $('.post__media', post);
      const img   = $('img', media);

      // Mask reveal (left → right) with a slight inner scale
      const tl = gsap.timeline({
        scrollTrigger: { trigger: post, start: 'top 85%' },
        delay: i * 0.08,
      });
      tl.fromTo(media, { clipPath: 'inset(0% 100% 0% 0%)' }, { clipPath: 'inset(0% 0% 0% 0%)', duration: 1.1, ease: 'power3.inOut' }, 0)
        .fromTo(img,   { scale: 1.25 }, { scale: 1, duration: 1.4, ease: 'power3.out' }, 0)
        .from([$('.post__date', post), $('.post__title', post)], { y: 20, autoAlpha: 0, duration: 0.7, stagger: 0.1, ease: 'power2.out' }, 0.4);
    });
  }

  /* ========================================================================
     12. AWARDS & RECOGNITIONS
     ======================================================================== */
  function initAwards() {
    if (reduce) return;

    // Duplicated heading: the two layers drift in opposite directions
    const trigger = { trigger: '.awards__heading', start: 'top bottom', end: 'bottom top', scrub: true };
    gsap.fromTo('.awards__title--front', { y: 40 },  { y: -40, ease: 'none', scrollTrigger: trigger });
    gsap.fromTo('.awards__title--back',  { y: -30, x: 14 }, { y: 50, x: -14, ease: 'none', scrollTrigger: trigger });

    // Rows slide in
    gsap.from('.award', {
      y: 40, autoAlpha: 0, duration: 0.9, stagger: 0.12, ease: 'power3.out',
      scrollTrigger: { trigger: '.awards__list', start: 'top 85%' },
    });
  }

  /* ========================================================================
     13. FINAL CTA + FOOTER
     ======================================================================== */
  function initCTA() {
    const ring = $('.cta__ring');
    if (ring && !reduce) {
      gsap.to(ring, { rotation: 360, duration: 30, ease: 'none', repeat: -1 });
      gsap.fromTo(ring, { scale: 0.85 }, {
        scale: 1.05, ease: 'none',
        scrollTrigger: { trigger: '.cta', start: 'top bottom', end: 'bottom top', scrub: true },
      });
    }

    // Magnetic button: pulls toward the cursor within 100px of the button
    const zone = $('.magnetic-zone');
    const btn  = $('.magnetic');
    if (zone && btn && useCursor && !reduce) {
      const RADIUS = 100, STRENGTH = 0.35;
      const xTo = gsap.quickTo(btn, 'x', { duration: 0.8, ease: 'elastic.out(1, 0.4)' });
      const yTo = gsap.quickTo(btn, 'y', { duration: 0.8, ease: 'elastic.out(1, 0.4)' });

      window.addEventListener('pointermove', (e) => {
        const r  = zone.getBoundingClientRect();          // static box, so no jitter
        const cx = r.left + r.width / 2;
        const cy = r.top  + r.height / 2;
        const dx = Math.max(r.left - e.clientX, 0, e.clientX - r.right);
        const dy = Math.max(r.top  - e.clientY, 0, e.clientY - r.bottom);

        if (Math.hypot(dx, dy) <= RADIUS) {
          xTo((e.clientX - cx) * STRENGTH);
          yTo((e.clientY - cy) * STRENGTH);
        } else {
          xTo(0); yTo(0);
        }
      }, { passive: true });
    }

    // Bottom marquee (track holds two identical halves ⇒ xPercent -50 loops)
    const marquee = $('.marquee__track');
    if (marquee && !reduce) {
      gsap.to(marquee, { xPercent: -50, ease: 'none', duration: 25, repeat: -1 });
    }
  }

  /* ------------------------------------------------------------------------
     Boot
     ------------------------------------------------------------------------ */
  function init() {
    initCursor();
    initHero();
    initStatement();
    initFire();
    initServices();
    initFall();
    initGallery();
    initWork();
    initProcess();
    initJournal();
    initAwards();
    initCTA();

    // Recalculate pin distances once images/fonts have settled
    window.addEventListener('load', () => ScrollTrigger.refresh());
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(() => ScrollTrigger.refresh());
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
